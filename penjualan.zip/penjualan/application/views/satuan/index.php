<!DOCTYPE html>
<html>
<head>
    <title><?= $title; ?></title>
</head>
<body>
    <div class="container mt-4">
    <h2><?= $title ?></h2>
    <div class="alert alert-info" role="alert">
        <strong>Informasi:</strong> Satuan digunakan untuk menentukan ukuran atau unit dari barang yang 
        dijual, seperti pcs, kg, liter, dus, dll. Ini membantu sistem dalam penghitungan stok, harga 
        jual, dan laporan yang akurat.
    </div>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama Satuan</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($satuan as $s): ?>
                <tr>
                    <td><?= $s['id'] ?></td>
                    <td><?= $s['name'] ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>