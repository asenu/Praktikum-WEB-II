<?php
$pdf->SetFont('Times','B',18);
$pdf->Cell(0,5,'LAPORAN DATA KUSTOMER',0,1,'C');
$pdf->Ln(5); 

$pdf->SetFont('Times','B',10);
$pdf->Cell(7,6,'NO',1,0,'C');
$pdf->Cell(37,6,'NIK',1,0,'C');
$pdf->Cell(50,6,'NAMA CUSTOMER',1,0,'C');
$pdf->Cell(36,6,'TELP',1,0,'C');
$pdf->Cell(60,6,'ALAMAT',1,1,'C');

$no = 1;
foreach ($data as $d) {
    $pdf->SetFont('Times','',9);
    $pdf->Cell(7,6,$no++,1,0,'C');
    $pdf->Cell(37,6,$d['nik'],1,0);
    $pdf->Cell(50,6,$d['name'],1,0);
    $pdf->Cell(36,6,$d['telp'],1,0);
    $pdf->Cell(60,6,$d['alamat'],1,1);
}
