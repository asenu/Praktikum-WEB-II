<div class="container">
    <div class="card mb-4">
        <div class="card-header">
            <h4>Tambah Barang</h4>
        </div>
        <div class="card-body">
            <a href="<?= site_url('barang/add') ?>" class="btn btn-primary mb-3">
                <i class="fas fa-plus"></i> Tambah Barang
            </a>

        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h4>Daftar Barang</h4>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-bordered" id="tabelkelas" width="100%" cellspacing="0">
                    <thead class="table-dark">
                        <tr>
                            <th>No.</th>
                            <th>Barcode</th>
                            <th>Name</th>
                            <th>Satuan</th>
                            <th>Kategori</th>
                            <th>Stok</th>
                            <th>Harga Beli</th>
                            <th>Harga Jual</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; foreach ($barang as $b): ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $b->barcode ?></td>
                            <td><?= $b->name ?></td>
                            <td><?= $b->satuan ?></td>
                            <td><?= $b->kategori ?></td>
                            <td><?= $b->stok ?></td>
                            <td><?= number_format($b->harga_beli, 0, ',', '.') ?></td>
                            <td><?= number_format($b->harga_jual, 0, ',', '.') ?></td>
                            <td>
                                <a href="<?= base_url('barang/getedit/' . $b->id) ?>" class="btn btn-sm btn-info">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <a href="<?= base_url('barang/delete/' . $b->id) ?>" 
                                   class="btn btn-sm btn-danger"
                                   onclick="return confirm('Ingin menghapus data barang ini?');">
                                    <i class="fas fa-trash"></i> Hapus
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
