<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * @property CI_DB_query_builder $db
 * @property Pdf $pdf
 */
class Report extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('Pdf');
    }
    public function kustomerlap()
    {
        $pdf = $this->pdf; 
        $pdf->AddPage();
        $data['pdf'] = $pdf;
        $data['data'] = $this->db->get('kustomer')->result_array();
        $this->load->view('kustomer/report_kustomer', $data);
        $pdf->Output('laporan_customer.pdf','I');
    }
    public function headerlap()
    {
        $pdf = new FPDF('P', 'mm', 'A4');
        $pdf->AddPage();
        $data['pdf'] = $pdf;
        $this->load->view('kustomer/report_header_only', $data);
        $pdf->SetFont('Times', '', 10);
        $pdf->Output('laporan_header_only.pdf', 'I');
    }
    public function kustomerfull()
    {
        $pdf = new FPDF('P', 'mm', 'A4');
        $pdf->AddPage();

        $data['pdf'] = $pdf;
        $data['data'] = $this->db->get('kustomer')->result_array();

        $this->load->view('kustomer/report_full', $data);

        $pdf->Output('laporan_kustomer_full.pdf','I');
    }

}