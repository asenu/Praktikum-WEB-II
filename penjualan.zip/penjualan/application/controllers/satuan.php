<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Satuan extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Satuan_model');
    }
    public function index()
    {
        $data['title'] = 'Data Satuan';
        $data['satuan'] = $this->db->get('satuan')->result_array();
        $data['content'] = 'satuan/index';
        $this->load->view('template/main', $data);
    }
}