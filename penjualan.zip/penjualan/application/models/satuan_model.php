<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Satuan_model extends CI_Model {

    public function get_all_satuan()
    {
        return $this->db->get('satuan')->result_array();
    }
}
