<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class kustomer extends CI_Controller {
    public function laporan() {
        $data = array(
            'title' => 'Tambah Laporan Data kustomer',
            'content' => 'kustomer/laporan'
        );
        $this->load->view('template/main',$data);
    }
    public function headerlap() {
        $this->load->view('kustomer/report_header_only');
    }
}